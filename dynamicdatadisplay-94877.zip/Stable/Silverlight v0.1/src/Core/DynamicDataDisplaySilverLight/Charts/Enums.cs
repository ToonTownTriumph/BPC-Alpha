﻿namespace Microsoft.Research.DynamicDataDisplay
{
    public enum AxisPlacement
    {
        Left,
        Right,
        Top,
        Bottom
    }
}