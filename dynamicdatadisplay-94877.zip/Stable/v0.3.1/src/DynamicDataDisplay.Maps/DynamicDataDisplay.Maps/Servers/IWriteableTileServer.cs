﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.Research.DynamicDataDisplay.Charts.Maps
{
	public interface IWriteableTileServer : ITileServer, ITileStore
	{
	}
}
