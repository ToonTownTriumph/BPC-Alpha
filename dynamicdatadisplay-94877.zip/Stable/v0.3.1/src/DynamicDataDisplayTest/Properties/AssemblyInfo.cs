﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DynamicDataDisplayTest")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MSTLAB")]
[assembly: AssemblyProduct("DynamicDataDisplayTest")]
[assembly: AssemblyCopyright("Copyright © MSTLAB 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM componenets.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("2d7f4409-f644-49ea-ac45-7ed37ed21c8e")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("Microsoft.Pex, PublicKey=002400000480000094000000060200000024000052534131000400000100010057a289398cc79ca7e46cd08c3994ca4ec229dd91d5ab4047b1bfbef3833332beedad9bec4014cdf721177edb24fe644b0dd95ab436d262cac8640fc5a87082423be9f41db942c8d1fd622dc4b305424d4ce9baf88fd15735b7352a70587997681d7df9dd5635c5cec251fc84423ab0349538bf61ece4d8ee7a6f2d07d169b9ec")]
[assembly: InternalsVisibleTo("Microsoft.Pex, PublicKey=002400000480000094000000060200000024000052534131000400000100010057a289398cc79ca7e46cd08c3994ca4ec229dd91d5ab4047b1bfbef3833332beedad9bec4014cdf721177edb24fe644b0dd95ab436d262cac8640fc5a87082423be9f41db942c8d1fd622dc4b305424d4ce9baf88fd15735b7352a70587997681d7df9dd5635c5cec251fc84423ab0349538bf61ece4d8ee7a6f2d07d169b9ec")]
[assembly: InternalsVisibleTo("Microsoft.Pex, PublicKey=002400000480000094000000060200000024000052534131000400000100010057a289398cc79ca7e46cd08c3994ca4ec229dd91d5ab4047b1bfbef3833332beedad9bec4014cdf721177edb24fe644b0dd95ab436d262cac8640fc5a87082423be9f41db942c8d1fd622dc4b305424d4ce9baf88fd15735b7352a70587997681d7df9dd5635c5cec251fc84423ab0349538bf61ece4d8ee7a6f2d07d169b9ec")]
