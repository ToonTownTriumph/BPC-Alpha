﻿using System.Windows.Markup;
using Microsoft.Research.DynamicDataDisplay;

[assembly: XmlnsDefinition(D3AssemblyConstants.DefaultXmlNamespace, "D3PaletteControl")]