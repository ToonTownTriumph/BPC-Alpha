﻿This is a part of WPF DynamicDataDisplay - http://dynamicdatadisplay.codeplex.com/

Uses coastline data from http://rimmer.ngdc.noaa.gov/